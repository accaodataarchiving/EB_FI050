sap.ui.define(
    ["sap/suite/ui/generic/template/lib/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("br.com.eldoradobrasil.fi050.fi050.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);